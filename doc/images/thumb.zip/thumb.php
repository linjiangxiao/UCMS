<?php
function thumb($url,$new_w=200,$new_h=200,$quality=90) {
	if($oldfile=realpath(SystemRoot.$url)){
		$newpic=SystemRoot.UploadDir.DIRECTORY_SEPARATOR.'thumb'.DIRECTORY_SEPARATOR.date('Ym').DIRECTORY_SEPARATOR.md5($url.$new_w.$new_h.$quality).'.jpg';
		$newurl=SystemDir.UploadDir.'/thumb/'.date('Ym').'/'.md5($url.$new_w.$new_h.$quality).'.jpg';
		if(is_file($newpic)) {
			Return $newurl;
		}
		createDir(dirname($newpic));
		$picinfo= @getimagesize($oldfile);
		if(!$picinfo) {
			Return $url;
		}
		if($new_w/$new_h>=$picinfo[0]/$picinfo[1]) {
			$w=$picinfo[0];
			$h=($picinfo[0]/$new_w)*$new_h;
			$x=0;
			$y=($picinfo[1]-$h)/2;
		}else {
			$w=($picinfo[1]/$new_h)*$new_w;
			$h=$picinfo[1];
			$x=($picinfo[0]-$w)/2;
			$y=0;
		}
		$bigpic = image_create($oldfile);
		if(!$bigpic) {
			Return $url;
		}
		$thumb = ImageCreateTrueColor($new_w, $new_h);
		imagecopyresampled($thumb,$bigpic,0,0,$x,$y,$new_w,$new_h,$w,$h);
		$thumb_save=imagejpeg($thumb, $newpic, $quality);
		imagedestroy($bigpic);
		imagedestroy($thumb);
		if($thumb_save) {Return $newurl;}
	}
	Return $url;
}
function image_create($pic_path) {
	$imginfo= @getimagesize($pic_path);
	if(!isset($imginfo['mime'])) {
		Return false;
	}
	if($imginfo['mime']==='image/jpeg') {
		Return imageCreateFromJPEG($pic_path);
	}
	if($imginfo['mime']==='image/png') {
		Return ImageCreateFromPNG($pic_path);
	}
	if($imginfo['mime']==='image/gif') {
		Return imageCreateFromGIF($pic_path);
	}
	if($imginfo['mime']==='image/x-ms-bmp') {
		Return imageCreateFromBMP($pic_path);
	}
	Return false;
}