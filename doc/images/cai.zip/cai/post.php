<?php
require('inc/config.php');
if(isset($_GET['channels'])) {
	$channels=getchannelscache();
	if(count($channels)>0) {
		echo('<channels>');
		foreach($channels as $val) {
			if($val['ckind']==2) {
				echo('<channel>'.$val['cid'].'-|-'.$val['name'].'</channel>');
			}
		}
		echo('</channels>');
	}
}
if(isset($_POST) && count($_POST)>0) {
	$article=$_POST;
	if(!isset($article['cid']) && isset($_GET['cid'])) {
		$article['cid']=$_GET['cid'];
	}elseif(!isset($article['cid'])) {
		die('no cid');
	}
	$id=ainsert($article);
	if(is_numeric($id)) {
		echo('ok');
	}else {
		echo($id);
	}
}
?>