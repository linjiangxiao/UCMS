<?php
function uploadfile($name,$max_size=0,$kind='',$filedir='') {
	if(!isset($_FILES[$name])) {
		Return array('file'=>'','error'=>'上传错误');
	}
	if (!empty($_FILES[$name]['error'])) {
		switch($_FILES[$name]['error']){
			case '1':
				$error = '超过系统允许的大小';
				break;
			case '2':
				$error = '超过表单允许的大小';
				break;
			case '3':
				$error = '文件只有部分被上传';
				break;
			case '4':
				$error = '请选择文件';
				break;
			case '6':
				$error = '找不到临时目录';
				break;
			case '7':
				$error = '写文件到硬盘出错';
				break;
			case '8':
				$error = 'File upload stopped by extension';
				break;
			case '999':
			default:
				$error = '未知错误';
		}
		Return array('file'=>'','error'=>$error,'name'=>$_FILES[$name]['name']);
	}
	if($max_size==0) {
		$max_size = '9999999';//不限制大小
	}else {
		$max_size = $max_size;//单位Kb,限制上传大小
	}
	if ($_FILES[$name]['size'] > $max_size*1024) {
		Return array('file'=>'','error'=>'上传文件大小超过限制','name'=>$_FILES[$name]['name']);
	}
	$ext_arr = array(
		'image' => array('gif', 'jpg', 'jpeg', 'png', 'bmp','blob','webp'),
		'media' => array('flv', 'mp3','mp4','wav', 'wma', 'wmv', 'mid', 'avi', 'mpg', 'asf', 'rm', 'rmvb','swf'),
		'file' => array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'txt', 'zip', 'rar', 'gz', 'bz2','pdf','rar','tar','torrent','apk','ipa','psd'),
	);
	$temp_arr = explode(".", $_FILES[$name]['name']);
	$file_ext = array_pop($temp_arr);
	$file_ext = strtolower(trim($file_ext));
	foreach($ext_arr as $key=>$val) {
		if(in_array($file_ext, $val) && ($kind==$key || $kind=='')) {
			$file_kind_dir=$key;
			break;
		}
	}
	if(!isset($file_kind_dir)) {
		Return array('file'=>'','error'=>"上传文件扩展名是不允许的扩展名",'name'=>$_FILES[$name]['name']);
	}
	if (in_array($file_ext, $ext_arr[$file_kind_dir]) === false) {
		Return array('file'=>'','error'=>"上传文件扩展名是不允许的扩展名",'name'=>$_FILES[$name]['name']);
	}
	if($filedir=='') {
		$filedir=SystemRoot.UploadDir.'/'.$file_kind_dir.'/'.date('Ymd').'/';
		$urldir=SystemDir.UploadDir.'/'.$file_kind_dir.'/'.date('Ymd').'/';
	}else {
		$filedir=SystemRoot.$filedir;
		$urldir=SystemDir.$filedir;
	}
	$filename=substr(md5(time().rand(10000, 99999)),0,9) .'.'.$file_ext;
	createDir($filedir);
	$save_path=$filedir.$filename;
	$fileurl=$urldir.$filename;
	if (move_uploaded_file($_FILES[$name]['tmp_name'], $save_path) === false) {
		Return array('file'=>'','error'=>'上传错误','name'=>$_FILES[$name]['name']);
	}else {
		Return array('file'=>$fileurl,'error'=>'','name'=>$_FILES[$name]['name']);
	}
	
}